package com.elavon.app.api.response;

import java.util.HashSet;
import java.util.Set;
import com.elavon.app.api.entity.Client;

public class ResponseBean {

	private Long id;
	private String storeName;
	private String storeAddress;
	private String mobileNumber;
	private String email;
	private Set<Client> countries = new HashSet<>();
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getStoreAddress() {
		return storeAddress;
	}
	public void setStoreAddress(String storeAddress) {
		this.storeAddress = storeAddress;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Set<Client> getCountries() {
		return countries;
	}
	public void setCountries(Set<Client> countries) {
		this.countries = countries;
	}
	
	
}
