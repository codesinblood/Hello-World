package com.elavon.app.api.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.neo4j.repository.query.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.elavon.app.api.entity.CAN;

@Repository
public interface CanRepo extends Neo4jRepository<CAN, Long> {
	Optional<CAN> findByCanCode(String chainCode);

	Optional<CAN> findByCanName(String chainName);

	@Query("MATCH (p:CAN { canName={canName}) RETURN p")
	public List<CAN> getAllMIDSUnderChain(@Param("canName") String canName);
}
