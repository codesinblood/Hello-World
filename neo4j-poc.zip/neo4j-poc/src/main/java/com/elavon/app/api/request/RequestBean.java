package com.elavon.app.api.request;

import java.util.List;
import java.util.Set;
import com.elavon.app.api.entity.CAN;
import com.elavon.app.api.entity.Client;
import com.elavon.app.api.entity.NTT;
import com.elavon.app.api.entity.DIM;

public class RequestBean {

	private Long id;
	private String clientCode;
	private String clientGroupName;
	private String clientName;
	private String midId;
	private String midName;
	private String nodeName;
	private String entityCode;
	private String entityName;
	private String chainCode;
	private String chainName;
	private Boolean isChain;
	private Boolean isCan;
	private String chainEntityCode;
	private List<RequestBean> dimList;
	private Set<CAN> chainEntity;
	private Set<NTT> entityEntity;
	private Set<Client> clientGroups;
	private Set<NTT> entitiesOfEntity;
	private Set<CAN> chainsOfChain;
	private Set<CAN> canOfCan;
	private Set<NTT> nttOfNtt;
	
	
	

	public Set<NTT> getNttOfNtt() {
		return nttOfNtt;
	}

	public void setNttOfNtt(Set<NTT> nttOfNtt) {
		this.nttOfNtt = nttOfNtt;
	}

	private String dimId;
	private String dimCode;
	private String dimName;
	private String rootName;
	private String nttCode;
	private String nttName;
	private String canCode;
	public Set<CAN> getCanOfCan() {
		return canOfCan;
	}

	public void setCanOfCan(Set<CAN> canOfCan) {
		this.canOfCan = canOfCan;
	}

	private String canName;

	public String getDimCode() {
		return dimCode;
	}

	public void setDimCode(String dimCode) {
		this.dimCode = dimCode;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getDimId() {
		return dimId;
	}

	public void setDimId(String dimId) {
		this.dimId = dimId;
	}

	public String getDimName() {
		return dimName;
	}

	public void setDimName(String dimName) {
		this.dimName = dimName;
	}

	public String getRootName() {
		return rootName;
	}

	public void setRootName(String rootName) {
		this.rootName = rootName;
	}

	public String getNttCode() {
		return nttCode;
	}

	public void setNttCode(String nttCode) {
		this.nttCode = nttCode;
	}

	public String getNttName() {
		return nttName;
	}

	public void setNttName(String nttName) {
		this.nttName = nttName;
	}

	public String getCanCode() {
		return canCode;
	}

	public void setCanCode(String canCode) {
		this.canCode = canCode;
	}

	public String getCanName() {
		return canName;
	}

	public void setCanName(String canName) {
		this.canName = canName;
	}

	public Boolean getIsCan() {
		return isCan;
	}

	public void setIsCan(Boolean isCan) {
		this.isCan = isCan;
	}

	public Set<NTT> getEntitiesOfEntity() {
		return entitiesOfEntity;
	}

	public void setEntitiesOfEntity(Set<NTT> entitiesOfEntity) {
		this.entitiesOfEntity = entitiesOfEntity;
	}

	public Set<CAN> getChainsOfChain() {
		return chainsOfChain;
	}

	public void setChainsOfChain(Set<CAN> chainsOfChain) {
		this.chainsOfChain = chainsOfChain;
	}

	public Boolean getIsChain() {
		return isChain;
	}

	public void setIsChain(Boolean isChain) {
		this.isChain = isChain;
	}

	public String getChainEntityCode() {
		return chainEntityCode;
	}

	public void setChainEntityCode(String chainEntityCode) {
		this.chainEntityCode = chainEntityCode;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClientCode() {
		return clientCode;
	}

	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}

	public String getClientGroupName() {
		return clientGroupName;
	}

	public void setClientGroupName(String clientGroupName) {
		this.clientGroupName = clientGroupName;
	}

	public String getMidId() {
		return midId;
	}

	public void setMidId(String midId) {
		this.midId = midId;
	}

	public String getMidName() {
		return midName;
	}

	public void setMidName(String midName) {
		this.midName = midName;
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public String getEntityCode() {
		return entityCode;
	}

	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getChainCode() {
		return chainCode;
	}

	public void setChainCode(String chainCode) {
		this.chainCode = chainCode;
	}

	public String getChainName() {
		return chainName;
	}

	public void setChainName(String chainName) {
		this.chainName = chainName;
	}

	

	public List<RequestBean> getDimList() {
		return dimList;
	}

	public void setDimList(List<RequestBean> dimList) {
		this.dimList = dimList;
	}

	Set<CAN> canSet;
	Set<NTT> nttSet;
	

	public Set<CAN> getChainEntity() {
		return chainEntity;
	}

	public void setChainEntity(Set<CAN> chainEntity) {
		this.chainEntity = chainEntity;
	}

	public Set<NTT> getNttSet() {
		return nttSet;
	}

	public void setNttSet(Set<NTT> nttSet) {
		this.nttSet = nttSet;
	}

	public Set<CAN> getCanSet() {

		return canSet;
	}

	public void setCanSet(Set<CAN> canSet) {
		this.canSet = canSet;
	}

	public Set<NTT> getEntityEntity() {
		return entityEntity;
	}

	public void setEntityEntity(Set<NTT> entityEntity) {
		this.entityEntity = entityEntity;
	}

	public Set<Client> getClientGroups() {
		return clientGroups;
	}

	public void setClientGroups(Set<Client> clientGroups) {
		this.clientGroups = clientGroups;
	}

}
