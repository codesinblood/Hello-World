package com.elavon.app.api.entity;

import java.util.List;

import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;
import org.neo4j.ogm.annotation.Transient;
import org.neo4j.ogm.annotation.Relationship.Direction;
import org.springframework.data.neo4j.core.schema.GeneratedValue;
import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.Node;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Node(primaryLabel = "DIM")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DIM{

	@Id
	@GeneratedValue
	private Long id;
	private String dimCode;

	private String dimName;

	private boolean isChain;

	public boolean getIsChain() {
		return isChain;
	}

	public void setIsChain(boolean isChain) {
		this.isChain = isChain;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDimCode() {
		return dimCode;
	}

	public void setDimCode(String dimCode) {
		this.dimCode = dimCode;
	}

	public String getDimName() {
		return dimName;
	}

	public void setDimName(String dimName) {
		this.dimName = dimName;
	}

	public void setChain(boolean isChain) {
		this.isChain = isChain;
	}

}
