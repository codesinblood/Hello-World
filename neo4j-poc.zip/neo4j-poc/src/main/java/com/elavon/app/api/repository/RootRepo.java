package com.elavon.app.api.repository;

import java.util.Optional;

import org.neo4j.driver.internal.shaded.reactor.core.publisher.Mono;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.elavon.app.api.entity.Root;
import com.elavon.app.api.entity.Client;

@Repository
public interface RootRepo extends Neo4jRepository<Root, Long> {
	
	Optional<Root> findByRootName(String rootName);
}
