package com.elavon.app.api.entity;

import java.util.List;
import java.util.Set;

import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;
import org.neo4j.ogm.annotation.Relationship.Direction;
import org.neo4j.ogm.annotation.RelationshipEntity;
import org.springframework.data.neo4j.core.schema.GeneratedValue;
import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.Node;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Node(primaryLabel = "CLIENT")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Client {

	@Id
	@GeneratedValue
	private Long id;
	private String clientCode;
	private String clientName;

	@Relationship(type = "CAN", direction = Direction.OUTGOING)
	private Set<CAN> can;
	@Relationship(type = "NTT", direction = Direction.OUTGOING)
	private Set<NTT> ntt;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClientCode() {
		return clientCode;
	}

	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public Set<CAN> getCan() {
		return can;
	}

	public void setCan(Set<CAN> can) {
		this.can = can;
	}

	public Set<NTT> getNtt() {
		return ntt;
	}

	public void setNtt(Set<NTT> ntt) {
		this.ntt = ntt;
	}

}
