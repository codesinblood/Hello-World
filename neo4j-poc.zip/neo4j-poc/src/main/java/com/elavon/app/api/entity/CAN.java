package com.elavon.app.api.entity;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Property;
import org.neo4j.ogm.annotation.Relationship;
import org.neo4j.ogm.annotation.RelationshipEntity;
import org.neo4j.ogm.annotation.Relationship.Direction;
import org.springframework.data.neo4j.core.schema.GeneratedValue;
import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.Node;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Node(primaryLabel = "CAN")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CAN {

	@Id
	@GeneratedValue
	private Long id;
	private String canCode;
	private String canName;

	@Relationship(type = "CAN_OF_CAN", direction = Direction.OUTGOING)
	@Property(name = "CAN_OF_CAN")
	private Set<CAN> canOfCan =new HashSet<>();

	
	@Relationship(type = "CAN_TO_DIM", direction = Direction.OUTGOING)	
	private List<DIM> canToDim;
	
	
	
	public List<DIM> getCanToDim() {
		return canToDim;
	}

	public void setCanToDim(List<DIM> canToDim) {
		this.canToDim = canToDim;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCanCode() {
		return canCode;
	}

	public void setCanCode(String canCode) {
		this.canCode = canCode;
	}

	public String getCanName() {
		return canName;
	}

	public void setCanName(String canName) {
		this.canName = canName;
	}

	public Set<CAN> getCanOfCan() {
		return canOfCan;
	}

	public void setCanOfCan(Set<CAN> canOfCan) {
		this.canOfCan = canOfCan;
	}

	
}
