package com.elavon.app.api.entity;

import java.util.HashSet;
import java.util.Set;

import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Property;
import org.neo4j.ogm.annotation.Relationship;
import org.neo4j.ogm.annotation.Relationship.Direction;
import org.neo4j.ogm.driver.TypeSystem;
import org.neo4j.ogm.metadata.DomainInfo;
import org.springframework.data.neo4j.core.schema.DynamicLabels;
import org.springframework.data.neo4j.core.schema.GeneratedValue;
import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.Node;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Node(primaryLabel = "ROOT")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Root {

	@Id
	@GeneratedValue
	private Long id;

	@Relationship(type = "CLIENT", direction = Direction.OUTGOING)
	private Set<Client> client;

	private String rootName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Set<Client> getClient() {
		return client;
	}

	public void setClients(Set<Client> client) {
		this.client = client;
	}

	public String getRootName() {
		return rootName;
	}

	public void setRootName(String rootName) {
		this.rootName = rootName;
	}

}
