package com.elavon.app.api.entity;

import java.util.List;
import java.util.Set;

import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Property;
import org.neo4j.ogm.annotation.Relationship;
import org.neo4j.ogm.annotation.RelationshipEntity;
import org.neo4j.ogm.annotation.Relationship.Direction;
import org.springframework.data.neo4j.core.schema.GeneratedValue;
import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.Node;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Node(primaryLabel = "NTT")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class NTT {

	@Id
	@GeneratedValue
	private Long id;
	private String nttCode;
	private String nttName;

	@Relationship(type = "NTT_OF_NTT", direction = Direction.OUTGOING)
	@Property(name = "NTT_OF_NTT")
	private Set<NTT> nttOfNtt;
	
	
	@Relationship(type = "NTT_TO_DIM", direction = Direction.OUTGOING)	
	private List<DIM> nttToDim;

	
	
	

	public Set<NTT> getNttOfNtt() {
		return nttOfNtt;
	}

	public void setNttOfNtt(Set<NTT> nttOfNtt) {
		this.nttOfNtt = nttOfNtt;
	}

	public List<DIM> getNttToDim() {
		return nttToDim;
	}

	public void setNttToDim(List<DIM> nttToDim) {
		this.nttToDim = nttToDim;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNttCode() {
		return nttCode;
	}

	public void setNttCode(String nttCode) {
		this.nttCode = nttCode;
	}

	public String getNttName() {
		return nttName;
	}

	public void setNttName(String nttName) {
		this.nttName = nttName;
	}

	
	

	

}
