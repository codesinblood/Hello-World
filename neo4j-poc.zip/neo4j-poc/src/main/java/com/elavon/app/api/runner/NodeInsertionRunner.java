//package com.elavon.app.api.runner;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Comparator;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//import java.util.stream.Collectors;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.core.Ordered;
//import org.springframework.core.annotation.Order;
//import org.springframework.data.domain.Page;
//import org.springframework.stereotype.Component;
//import org.springframework.web.bind.annotation.PostMapping;
//
//import com.elavon.app.api.entity.CAN;
//import com.elavon.app.api.entity.Client;
//import com.elavon.app.api.entity.NTT;
//import com.elavon.app.api.entity.DIM;
//import com.elavon.app.api.request.WallmartRequestBean;
//import com.elavon.app.api.service.MPSService;
//
////@Component
//public class NodeInsertionRunner implements CommandLineRunner {
//	public static final Logger logger = LoggerFactory.getLogger(NodeInsertionRunner.class);
//
//	@Autowired
//	MPSService mpsService;
//
//	@Override
//	public void run(String... args) throws Exception {
//		System.out.println("Runner class called");
//		WallmartRequestBean clientGroup = new WallmartRequestBean();
//		try {
//			clientGroup.setNodeName("ROOT");
//			Client clientGroup1 = new Client();
//			clientGroup1.setClientCode("" + 1);
//			clientGroup1.setClientGroupName("Client 1");
//			Client clientGroup2 = new Client();
//			clientGroup2.setClientCode("" + 2);
//			clientGroup2.setClientGroupName("Client 2");
//			Set<Client> clientGroups = new HashSet<Client>();
//			clientGroups.add(clientGroup1);
//			clientGroups.add(clientGroup2);
//			clientGroup.setClientGroups(clientGroups);
//			mpsService.addClientGroup(clientGroup);
//		} finally {
//			clientGroup = null;
//			System.gc();
//		}
//		WallmartRequestBean wallmartRequestBean = new WallmartRequestBean();
//		try {
//			wallmartRequestBean.setClientCode("1");
//			Set<CAN> chainSet = new HashSet<CAN>();
//			for (int i = 1; i <= 300; i++) {
//				CAN ss = new CAN();
//				ss.setChainCode("" + i);
//				ss.setChainName("CAN " + i);
//				chainSet.add(ss);
//			}
//			wallmartRequestBean.setChainEntity(chainSet);
//			mpsService.addChain(wallmartRequestBean);
//		} finally {
//			wallmartRequestBean = null;
//			System.gc();
//		}
//
//		WallmartRequestBean wallmartRequestBeanEntity = new WallmartRequestBean();
//		try {
//			wallmartRequestBeanEntity.setClientCode("1");
//			Set<NTT> entitySet = new HashSet<NTT>();
//			for (int i = 301; i <= 600; i++) {
//				NTT ss = new NTT();
//				ss.setEntityCode("" + i);
//				ss.setEntityName("NTT " + i);
//				entitySet.add(ss);
//			}
//			wallmartRequestBeanEntity.setEntityEntity(entitySet);
//			mpsService.addEntity(wallmartRequestBeanEntity);
//
//		} finally {
//			wallmartRequestBeanEntity = null;
//			System.gc();
//		}
//		WallmartRequestBean wallmartRequestBean2 = new WallmartRequestBean();
//		try {
//			wallmartRequestBean2.setClientCode("2");
//			Set<CAN> chainSet1 = new HashSet<CAN>();
//			for (int i = 601; i <= 900; i++) {
//				CAN ss = new CAN();
//				ss.setChainCode("" + i);
//				ss.setChainName("CAN " + i);
//				chainSet1.add(ss);
//			}
//			wallmartRequestBean2.setChainEntity(chainSet1);
//			mpsService.addChain(wallmartRequestBean2);
//		} finally {
//			wallmartRequestBean2 = null;
//			System.gc();
//		}
//
//		WallmartRequestBean wallmartRequestBeanEntity2 = new WallmartRequestBean();
//		try {
//			wallmartRequestBeanEntity2.setClientCode("2");
//			Set<NTT> entitySet2 = new HashSet<NTT>();
//			for (int i = 901; i <= 1200; i++) {
//				NTT ss = new NTT();
//				ss.setEntityCode("" + i);
//				ss.setEntityName("NTT " + i);
//				entitySet2.add(ss);
//			}
//			wallmartRequestBeanEntity2.setEntityEntity(entitySet2);
//			mpsService.addEntity(wallmartRequestBeanEntity2);
//
//		} finally {
//			wallmartRequestBeanEntity2 = null;
//			System.gc();
//		}
//		Integer counter = 1;
//		for (int i = 1; i <= 300; i++) {
//			WallmartRequestBean wallmartRequestBeanEntity3 = new WallmartRequestBean();
//			try {
//				wallmartRequestBeanEntity3.setClientCode("1");
//				wallmartRequestBeanEntity3.setIsChain(true);
//				wallmartRequestBeanEntity3.setChainEntityCode("" + i);
//				Set<DIM> midEntity = new HashSet<DIM>();
//				for (int j = 1; j <= 100; j++) {
//					DIM md = new DIM();
//					md.setMidCode("" + counter.intValue());
//					md.setMidName("DIM " + counter.intValue());
//					NTT ent = new NTT();
//					ent.setEntityCode("" + (300 + i));
//					md.setEntityCode(ent);
//					midEntity.add(md);
//					counter++;
//				}
//				wallmartRequestBeanEntity3.setMidEntity(midEntity);
//				mpsService.addMID(wallmartRequestBeanEntity3);
//			} finally {
//				wallmartRequestBeanEntity3 = null;
//				System.gc();
//			}
//		}
//
//		for (int i = 301; i <= 600; i++) {
//			WallmartRequestBean wallmartRequestBeanEntity3 = new WallmartRequestBean();
//			try {
//				wallmartRequestBeanEntity3.setClientCode("1");
//				wallmartRequestBeanEntity3.setIsChain(false);
//				wallmartRequestBeanEntity3.setChainEntityCode("" + i);
//				Set<DIM> midEntity = new HashSet<DIM>();
//				for (int j = 0; j <= 100; j++) {
//					DIM md = new DIM();
//					md.setMidCode("" + counter.intValue());
//					md.setMidName("DIM " + counter.intValue());
//					midEntity.add(md);
//					counter++;
//				}
//				wallmartRequestBeanEntity3.setMidEntity(midEntity);
//				mpsService.addMID(wallmartRequestBeanEntity3);
//				wallmartRequestBeanEntity3 = null;
//			} finally {
//				wallmartRequestBeanEntity3 = null;
//				System.gc();
//			}
//		}
//
//		for (int i = 601; i <= 900; i++) {
//			int count = 1;
//			WallmartRequestBean wallmartRequestBeanEntity4 = new WallmartRequestBean();
//			try {
//				wallmartRequestBeanEntity4.setClientCode("2");
//				wallmartRequestBeanEntity4.setIsChain(true);
//				wallmartRequestBeanEntity4.setChainEntityCode("" + i);
//				Set<DIM> midEntity = new HashSet<DIM>();
//				for (int j = 0; j <= 100; j++) {
//					DIM md = new DIM();
//					md.setMidCode("" + counter.intValue());
//					md.setMidName("DIM " + counter.intValue());
//					NTT ent = new NTT();
//					ent.setEntityCode("" + (count + 900));
//					md.setEntityCode(ent);
//					midEntity.add(md);
//					counter++;
//				}
//				count++;
//				wallmartRequestBeanEntity4.setMidEntity(midEntity);
//				mpsService.addMID(wallmartRequestBeanEntity4);
//			} finally {
//				wallmartRequestBeanEntity4 = null;
//				System.gc();
//			}
//		}
//
//		for (int i = 901; i <= 1200; i++) {
//			WallmartRequestBean wallmartRequestBeanEntity4 = new WallmartRequestBean();
//			try {
//				wallmartRequestBeanEntity4.setClientCode("2");
//				wallmartRequestBeanEntity4.setIsChain(false);
//				wallmartRequestBeanEntity4.setChainEntityCode("" + i);
//				Set<DIM> midEntity = new HashSet<DIM>();
//				for (int j = 0; j <= 100; j++) {
//					DIM md = new DIM();
//					md.setMidCode("" + (counter.intValue()));
//					md.setMidName("DIM " + (counter.intValue()));
//					midEntity.add(md);
//					counter++;
//				}
//				wallmartRequestBeanEntity4.setMidEntity(midEntity);
//				mpsService.addMID(wallmartRequestBeanEntity4);
//			} finally {
//				wallmartRequestBeanEntity4 = null;
//				System.gc();
//			}
//
//		}
//
//		int chaincode = 1201;
//		for (int cc = 20; cc <= 30; cc++) {
//			WallmartRequestBean wallmartRequestBeanChain = new WallmartRequestBean();
//
//			try {
//				wallmartRequestBeanChain.setClientCode("1");
//				wallmartRequestBeanChain.setChainCode("" + cc);
//				Set<CAN> cocSet = new HashSet<CAN>();
//				for (int i = 1; i <= 10; i++) {
//					CAN ss = new CAN();
//					ss.setChainCode("" + chaincode);
//					ss.setChainName("CAN " + chaincode);
//					cocSet.add(ss);
//					chaincode++;
//				}
//				wallmartRequestBeanChain.setChainsOfChain(cocSet);
//				mpsService.addChainsUnderChain(wallmartRequestBeanChain);
//			} finally {
//				wallmartRequestBeanChain = null;
//				System.gc();
//			}
//		}
//
//		int entityCode = 1401;
//		for (int cc = 410; cc <= 420; cc++) {
//			WallmartRequestBean wallmartRequestBeanChain = new WallmartRequestBean();
//			try {
//				wallmartRequestBeanChain.setClientCode("1");
//				wallmartRequestBeanChain.setEntityCode("" + cc);
//				Set<NTT> cocSet = new HashSet<NTT>();
//				for (int i = 1; i <= 10; i++) {
//					NTT ss = new NTT();
//					ss.setEntityCode("" + entityCode);
//					ss.setEntityName("NTT " + entityCode);
//					cocSet.add(ss);
//					entityCode++;
//				}
//				wallmartRequestBeanChain.setEntitiesOfEntity(cocSet);
//				mpsService.addEntitiesUnderEntity(wallmartRequestBeanChain);
//			} finally {
//				wallmartRequestBeanChain = null;
//				System.gc();
//			}
//		}
//
//		Integer chainOfchaincounter = 125000;
//		for (int i = 1201; i <= 1210; i++) {
//			WallmartRequestBean wallmartRequestBeanEntity3 = new WallmartRequestBean();
//			try {
//				wallmartRequestBeanEntity3.setClientCode("1");
//				wallmartRequestBeanEntity3.setIsChain(true);
//				wallmartRequestBeanEntity3.setChainEntityCode("" + i);
//				Set<DIM> midEntity = new HashSet<DIM>();
//				for (int j = 1; j <= 100; j++) {
//					DIM md = new DIM();
//					md.setMidCode("" + chainOfchaincounter.intValue());
//					md.setMidName("DIM " + chainOfchaincounter.intValue());
//					NTT ent = new NTT();
//					ent.setEntityCode("" + (200 + i));
//					md.setEntityCode(ent);
//					midEntity.add(md);
//					chainOfchaincounter++;
//				}
//				wallmartRequestBeanEntity3.setMidEntity(midEntity);
//				mpsService.addMID(wallmartRequestBeanEntity3);
//			} finally {
//				wallmartRequestBeanEntity3 = null;
//				System.gc();
//			}
//		}
//
//		for (int i = 1401; i <= 1500; i++) {
//			WallmartRequestBean wallmartRequestBeanEntity3 = new WallmartRequestBean();
//			try {
//				wallmartRequestBeanEntity3.setClientCode("1");
//				wallmartRequestBeanEntity3.setIsChain(false);
//				wallmartRequestBeanEntity3.setChainEntityCode("" + i);
//				Set<DIM> midEntity = new HashSet<DIM>();
//				for (int j = 0; j <= 100; j++) {
//					DIM md = new DIM();
//					md.setMidCode("" + chainOfchaincounter.intValue());
//					md.setMidName("DIM " + chainOfchaincounter.intValue());
//					// md.setEntityCode("" +counter.intValue());
//					midEntity.add(md);
//					chainOfchaincounter++;
//				}
//				wallmartRequestBeanEntity3.setMidEntity(midEntity);
//				mpsService.addMID(wallmartRequestBeanEntity3);
//			} finally {
//				wallmartRequestBeanEntity3 = null;
//				System.gc();
//			}
//		}
//
//		System.out.println("Runner class execution done");
//
//	}
//}
