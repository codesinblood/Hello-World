package com.elavon.app.api.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.neo4j.ogm.transaction.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.neo4j.core.Neo4jTemplate;
import org.springframework.stereotype.Service;

import com.elavon.app.api.entity.CAN;
import com.elavon.app.api.entity.Client;
import com.elavon.app.api.entity.NTT;
import com.elavon.app.api.entity.DIM;
import com.elavon.app.api.entity.Root;
import com.elavon.app.api.repository.CanRepo;
import com.elavon.app.api.repository.ClientRepo;
import com.elavon.app.api.repository.NTTRepo;
import com.elavon.app.api.repository.DIMRepo;
import com.elavon.app.api.repository.RootRepo;
import com.elavon.app.api.request.RequestBean;
import com.elavon.app.api.response.ResponseBean;

@Service
public class MainService {

	@Autowired
	RootRepo mpsRepository;
	@Autowired
	ClientRepo clientGroupRepository;
	@Autowired
	CanRepo chainRepository;
	@Autowired
	NTTRepo entityRepository;
	@Autowired
	DIMRepo midRepository;

	public String addClientGroup(RequestBean wallmartRequestBean) {
		Root mpsEntity = new Root();
		try {

			Optional<Root> mps = mpsRepository.findByRootName(wallmartRequestBean.getNodeName());
			if (mps.isPresent()) {
				mpsEntity = mps.get();
				mpsEntity.setId(mpsEntity.getId());
				mpsEntity.setRootName(wallmartRequestBean.getNodeName());
			} else {
				mpsEntity.setRootName(wallmartRequestBean.getNodeName());
			}
			Set<Client> clientList = new HashSet<>();
			for (Client clientGroup : wallmartRequestBean.getClientGroups()) {
				Client ce = new Client();
				Optional<Client> ec = clientGroupRepository.findByClientCode(clientGroup.getClientCode());
				if (ec.isPresent()) {
					ce = ec.get();
					ce.setClientCode(clientGroup.getClientCode());
					ce.setClientName(clientGroup.getClientName());
				} else {
					ce.setClientCode(clientGroup.getClientCode());
					ce.setClientName(clientGroup.getClientName());
				}
				clientList.add(ce);
			}
			mpsEntity.setClients(clientList);
			mpsEntity = mpsRepository.save(mpsEntity);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			mpsEntity = null;
			System.gc();
		}
		return "Client Group added successfully! ";
	}

	public String addChain(RequestBean wallmartRequestBean) {
		String result = null;
		Optional<Client> cgEntity = clientGroupRepository.findByClientCode(wallmartRequestBean.getClientCode());
		try {
			if (cgEntity.isPresent()) {
				Client cen = new Client();
				cen = cgEntity.get();
				Set<CAN> chainEntitySet = new HashSet<>();
				if (cen.getCan().size() > 0) {
					chainEntitySet.addAll(cen.getCan());
				}

				try {
					for (CAN chain : wallmartRequestBean.getCanSet()) {
						CAN ce = new CAN();
						Optional<CAN> ec = chainRepository.findByCanCode(chain.getCanCode());
						if (ec.isPresent()) {
							ce = ec.get();
							ce.setCanCode(ce.getCanCode());
							ce.setCanName(ce.getCanName());
						} else {
							ce.setCanCode(chain.getCanCode());
							ce.setCanName(chain.getCanName());
						}
						chainEntitySet.add(ce);
					}
					cen.setCan(chainEntitySet);
					clientGroupRepository.save(cen);
					result = "Can added successfully!";
				} finally {
					chainEntitySet = null;
					System.gc();
				}

			} else {
				result = "Client not found!";
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cgEntity = null;
			System.gc();
		}
		return result;
	}

	public String addEntity(RequestBean wallmartRequestBean) {
		String result = null;
		try {

			Optional<Client> cgEntity = clientGroupRepository.findByClientCode(wallmartRequestBean.getClientCode());
			if (cgEntity.isPresent()) {
				Client cen = new Client();
				cen = cgEntity.get();
				Set<NTT> entityEntitySet = new HashSet<>();
				if (cen.getCan().size() > 0) {
					entityEntitySet.addAll(cen.getNtt());
				}
				try {
					for (NTT chain : wallmartRequestBean.getNttSet()) {
						NTT ce = new NTT();
						Optional<NTT> ec = entityRepository.findByNttCode(chain.getNttCode());
						if (ec.isPresent()) {
							ce = ec.get();
							ce.setNttCode(ce.getNttCode());
							ce.setNttName(ce.getNttName());
						} else {
							ce.setNttCode(chain.getNttCode());
							ce.setNttName(chain.getNttName());
						}
						entityEntitySet.add(ce);
					}
					cen.setNtt(entityEntitySet);
					clientGroupRepository.save(cen);
					result = "NTT added successfully!";
				} finally {
					entityEntitySet = null;
					System.gc();
				}
			} else {
				result = "Client not found!";
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
		return result;
	}

	public String addChainsUnderChain(RequestBean wallmartRequestBean) {
		String result = null;
		try {

			Optional<CAN> ec = chainRepository.findByCanCode(wallmartRequestBean.getCanCode());
			if (ec.isPresent()) {
				CAN chainEntity = new CAN();
				chainEntity = ec.get();
				Set<CAN> chainEntitySet = new HashSet<>();
				if (chainEntity.getCanOfCan().size() > 0) {
					chainEntitySet.addAll(chainEntity.getCanOfCan());
				}
				try {
					for (CAN chain : wallmartRequestBean.getCanOfCan()) {
						CAN ce = new CAN();
						Optional<CAN> ec1 = chainRepository.findByCanCode(chain.getCanCode());
						if (ec1.isPresent()) {
							ce = ec1.get();
							ce.setCanCode(chain.getCanCode());
							ce.setCanName(chain.getCanName());
						} else {
							ce.setCanCode(chain.getCanCode());
							ce.setCanName(chain.getCanName());
						}
						chainEntitySet.add(ce);
					}
					chainEntity.setCanOfCan(chainEntitySet);
					chainRepository.save(chainEntity);
					result = "Chain added successfully!";
				} finally {
					chainEntitySet = null;
					System.gc();
				}
			} else {
				result = "Parent chain not found!";
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
		return result;
	}

	public String addEntitiesUnderEntity(RequestBean wallmartRequestBean) {
		String result = null;
		try {

			Optional<NTT> ec = entityRepository.findByNttCode(wallmartRequestBean.getNttCode());
			if (ec.isPresent()) {
				NTT entityEntity = new NTT();
				entityEntity = ec.get();
				Set<NTT> entityEntitySet = new HashSet<>();
				if (entityEntity.getNttOfNtt().size() > 0) {
					entityEntitySet.addAll(entityEntity.getNttOfNtt());
				}
				try {
					for (NTT ent : wallmartRequestBean.getNttOfNtt()) {
						NTT ce = new NTT();
						Optional<NTT> ec1 = entityRepository.findByNttCode(ent.getNttCode());
						if (ec1.isPresent()) {
							ce = ec.get();
							ce.setNttCode(ce.getNttCode());
							ce.setNttName(ent.getNttName());
						} else {
							ce.setNttCode(ent.getNttCode());
							ce.setNttName(ent.getNttName());
						}
						entityEntitySet.add(ce);
					}
					entityEntity.setNttOfNtt(entityEntitySet);
					entityRepository.save(entityEntity);
					result = "NTT added successfully!";
				} finally {
					entityEntitySet = null;
					System.gc();
				}
			} else {
				result = "Parent Entity not found!";
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
		return result;
	}

	public String addMID(RequestBean bean) {

		String result = null;
		try {
			if (bean.getIsChain()) {
				Optional<NTT> nttForMid = entityRepository.findByNttCode(bean.getNttCode()); // error
				if (nttForMid.isPresent()) {
					Optional<CAN> canForMid = chainRepository.findByCanCode(bean.getCanCode());
					if (canForMid.isPresent()) {

						CAN can = canForMid.get();
						NTT ntt = nttForMid.get();
						List<DIM> dimList = new ArrayList<DIM>();
						if (can.getCanToDim().size() > 0) {
							dimList.addAll(can.getCanToDim());
						}
						for (RequestBean b : bean.getDimList()) {
							Optional<DIM> isDim = midRepository.findByDimCode(b.getDimCode());
							DIM me = new DIM();
							if (isDim.isPresent()) {
								me = isDim.get();
								me.setDimCode(b.getDimCode());
								me.setDimName(b.getDimName());
								me.setIsChain(bean.getIsChain());
							} else {
								me.setDimCode(b.getDimCode());
								me.setDimName(b.getDimName());
								me.setIsChain(bean.getIsChain());
							}

							dimList.add(me);
						}

						can.setCanToDim(dimList);
						System.out.println("Started--->" + System.currentTimeMillis());
						chainRepository.save(can);
						ntt.setNttToDim(dimList);
						entityRepository.save(ntt);
						System.out.println("Done--->" + System.currentTimeMillis());

						can = null;
						ntt = null;
					} else {
						result = "CAN not found!";
					}
				} else {
					result = "NTT not found!";
				}
			} else {
				return addMMIDUnderEntity(bean);
			}

		} catch (

		Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public String addMMIDUnderEntity(RequestBean bean) {
		String result = "";
		Optional<NTT> nttForMid = entityRepository.findByNttCode(bean.getNttCode()); // error
		if (nttForMid.isPresent()) {
			NTT ntt = nttForMid.get();
			List<DIM> dimList = new ArrayList<DIM>();
			if (ntt.getNttToDim().size() > 0) {
				dimList.addAll(ntt.getNttToDim());
			}
			for (RequestBean b : bean.getDimList()) {
				Optional<DIM> isDim = midRepository.findByDimCode(b.getDimCode());
				DIM me = new DIM();
				if (isDim.isPresent()) {
					me = isDim.get();
					me.setDimCode(b.getDimCode());
					me.setDimName(b.getDimName());
				} else {
					me.setDimCode(b.getDimCode());
					me.setDimName(b.getDimName());
				}
				dimList.add(me);
			}
			ntt.setNttToDim(dimList);
			System.out.println("Started--->" + System.currentTimeMillis());
			entityRepository.save(ntt);
			System.out.println("Done--->" + System.currentTimeMillis());
			ntt = null;
		}
		return result;
	}

	public List<Client> getAllClientGroups() {
		return clientGroupRepository.findAll();
	}

	public List<NTT> getAllEntity() {
		return entityRepository.findAll();
	}

	public List<CAN> getAllChains() {
		return chainRepository.findAll();
	}

	public List<DIM> getAllMIDs() {
		return midRepository.findAll();
	}

	public Client getAllMIDSUnderCGL(String clientGroupName) {
		Client ent = new Client();
		Optional<Client> entity = clientGroupRepository.findByClientName(clientGroupName);
		if (entity.isPresent()) {
			ent = entity.get();
		}
		return ent;
	}

	public CAN getAllMIDsByChainName(String chainName) {
		CAN ent = new CAN();
		Optional<CAN> entity = chainRepository.findByCanName(chainName);
		if (entity.isPresent()) {
			ent = entity.get();
		}
		return ent;
	}

	public NTT getAllMIDsByEntityName(String entityName) {
		NTT ent = new NTT();
		Optional<NTT> entity = entityRepository.findByNttName(entityName);
		if (entity.isPresent()) {
			ent = entity.get();
		}
		return ent;
	}

	public List<DIM> getAllChainsUnderChain() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<DIM> getAllEntitiesUnderEntity() {
		// TODO Auto-generated method stub
		return null;
	}

}
