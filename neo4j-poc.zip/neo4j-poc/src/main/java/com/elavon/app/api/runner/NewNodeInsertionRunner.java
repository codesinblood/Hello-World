package com.elavon.app.api.runner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;

import com.elavon.app.api.entity.CAN;
import com.elavon.app.api.entity.Client;
import com.elavon.app.api.entity.NTT;
import com.elavon.app.api.entity.DIM;
import com.elavon.app.api.request.RequestBean;
import com.elavon.app.api.service.MainService;

@Component
public class NewNodeInsertionRunner implements CommandLineRunner {
	public static final Logger logger = LoggerFactory.getLogger(NewNodeInsertionRunner.class);

	@Autowired
	MainService mpsService;

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Runner class called");

// Add Client		
		RequestBean client = new RequestBean();
		try {
			client.setNodeName("ROOT");
			Client client1 = new Client();
			client1.setClientCode("" + 1);
			client1.setClientName("Client 1");
			Client client2 = new Client();
			client2.setClientCode("" + 2);
			client2.setClientName("Client 2");
			Set<Client> clients = new HashSet<Client>();
			clients.add(client1);
			clients.add(client2);
			client.setClientGroups(clients);
			mpsService.addClientGroup(client);
		} finally {
			client = null;
			System.gc();
		}

// Add CAN and NTT

		for (int i = 1; i <= 200; i++) {
			RequestBean wallmartRequestBean1 = new RequestBean();
			Set<CAN> chainSet = new HashSet<CAN>();
			Set<NTT> nttSet = new HashSet<NTT>();
			if (i >= 101 && i <= 200) {
				wallmartRequestBean1.setClientCode("2");
			} else {
				wallmartRequestBean1.setClientCode("1");
			}
			CAN ss = new CAN();
			ss.setCanCode("" + i);
			ss.setCanName("CAN " + i);
			chainSet.add(ss);
			NTT nt = new NTT();
			nt.setNttCode("" + i);
			nt.setNttName("NTT " + i);
			nttSet.add(nt);
			wallmartRequestBean1.setCanSet(chainSet);
			mpsService.addChain(wallmartRequestBean1);
			wallmartRequestBean1.setNttSet(nttSet);
			mpsService.addEntity(wallmartRequestBean1);
		}

		// CAN under CAN and NTT under NTT
		int cNcode = 201;
		for (int cc = 50; cc <= 150; cc++) {
			RequestBean bean = new RequestBean();
			try {
				if (cc >= 101) {
					bean.setClientCode("2");
				} else {
					bean.setClientCode("1");
				}
				bean.setCanCode("" + cc);
				bean.setNttCode("" + cc);
				Set<CAN> cocSet = new HashSet<CAN>();
				Set<NTT> nttSet = new HashSet<NTT>();
				for (int i = 1; i <= 10; i++) {
					CAN ss = new CAN();
					ss.setCanCode("" + cNcode);
					ss.setCanName("CAN " + cNcode);
					cocSet.add(ss);
					NTT nn = new NTT();
					nn.setNttCode("" + cNcode);
					nn.setNttName("NTT " + cNcode);
					nttSet.add(nn);
					cNcode++;
				}
				bean.setCanOfCan(cocSet);
				mpsService.addChainsUnderChain(bean);
				bean.setNttOfNtt(nttSet);
				mpsService.addEntitiesUnderEntity(bean);
			} finally {
				bean = null;
				System.gc();
			}
		}

// DIM	 Under CAN	and NTT
		Integer counter = 1201;
		for (int i = 1; i <= 1200; i++) {
			try {
				RequestBean ss = new RequestBean();
				if (i >= 601) {
					ss.setClientCode("2");
				} else {
					ss.setClientCode("1");
				}
				ss.setIsChain(true);
				ss.setNttCode("" + i);
				ss.setCanCode("" + i);
				List<RequestBean> beanList = new ArrayList<RequestBean>();
				for (int j = 1; j <= 200; j++) {
					if (i >= 550 && i <= 600) {
						ss.setIsChain(false);
					}
					if (i >= 1150 && i <= 1200) {
						ss.setIsChain(false);
					}
					RequestBean s = new RequestBean();
					s.setDimCode("" + counter.intValue());
					s.setDimName("DIM " + counter.intValue());
					counter++;
					beanList.add(s);
				}
				ss.setDimList(beanList);
				mpsService.addMID(ss);

			} finally {
				System.gc();
			}
		}
	}
}
