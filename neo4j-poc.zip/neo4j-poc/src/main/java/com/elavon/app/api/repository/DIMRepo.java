package com.elavon.app.api.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.neo4j.repository.query.Query;
import org.springframework.stereotype.Repository;

import com.elavon.app.api.entity.Root;
import com.elavon.app.api.entity.CAN;
import com.elavon.app.api.entity.Client;
import com.elavon.app.api.entity.NTT;
import com.elavon.app.api.entity.DIM;


@Repository
public interface DIMRepo extends Neo4jRepository<DIM, Long> {
	Optional<DIM> findByDimCode(String midCode);
	Optional<DIM> findByDimName(String midName);
	
	
}
