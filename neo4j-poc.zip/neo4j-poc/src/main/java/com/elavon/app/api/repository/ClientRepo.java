package com.elavon.app.api.repository;

import java.util.Optional;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import com.elavon.app.api.entity.Root;
import com.elavon.app.api.entity.Client;

@Repository
public interface ClientRepo extends Neo4jRepository<Client, Long> {
	Optional<Client> findByClientCode(String clientCode);
	Optional<Client> findByClientName(String clientGroupName);
}
