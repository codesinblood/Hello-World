package com.elavon.app.api.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elavon.app.api.entity.CAN;
import com.elavon.app.api.entity.Client;
import com.elavon.app.api.entity.NTT;
import com.elavon.app.api.entity.DIM;
import com.elavon.app.api.entity.Root;
import com.elavon.app.api.request.RequestBean;
import com.elavon.app.api.response.ResponseBean;
import com.elavon.app.api.service.MainService;

@RestController
@RequestMapping("/api/v1")

public class MainController {

	Logger logger = LoggerFactory.getLogger(MainController.class);

	@Autowired
	MainService mpsService;

	@PostMapping("/addClient")
	public String addClientGroup(@RequestBody RequestBean wallmartRequestBean) {
		return mpsService.addClientGroup(wallmartRequestBean);
	}

	@PostMapping("/addCan")
	public String addChain(@RequestBody RequestBean wallmartRequestBean) {
		return mpsService.addChain(wallmartRequestBean);
	}

	@PostMapping("/addNTT")
	public String addEntity(@RequestBody RequestBean wallmartRequestBean) {
		return mpsService.addEntity(wallmartRequestBean);
	}

	@PostMapping("/addCanUnderCan")
	public String addChainsUnderChain(@RequestBody RequestBean wallmartRequestBean) {
		return mpsService.addChainsUnderChain(wallmartRequestBean);
	}

	@PostMapping("/addNttUnderNtt")
	public String addEntitiesUnderEntity(@RequestBody RequestBean wallmartRequestBean) {
		return mpsService.addEntitiesUnderEntity(wallmartRequestBean);
	}

	@PostMapping("/addMID")
	public String addMID(@RequestBody RequestBean bean) {

		return mpsService.addMID(bean);
	}

	@GetMapping("/getAllClients")
	public List<Client> getAllClientGroups() {
		return mpsService.getAllClientGroups();
	}

	@GetMapping("/getAllNtts")
	public List<NTT> getAllEntity() {
		return mpsService.getAllEntity();
	}

	@GetMapping("/getAllCans")
	public List<CAN> getAllChains() {
		return mpsService.getAllChains();
	}

	@GetMapping("/getAllDims")
	public List<DIM> getAllMIDs() {
		return mpsService.getAllMIDs();
	}

	@GetMapping("/getAllDimsUnderClient/{client}")
	public Client getAllMIDSUnderCGL(@PathVariable("client") String client) {
		return mpsService.getAllMIDSUnderCGL(client);
	}

	@GetMapping("/getAllDimsByCanName/{canName}")
	public CAN getAllMIDsByChainName(@PathVariable("canName") String canName) {
		return mpsService.getAllMIDsByChainName(canName);
	}

	@GetMapping("/getAllDimsByNttName/{nttName}")
	public NTT getAllMIDsByEntityName(@PathVariable("nttName") String nttName) {
		return mpsService.getAllMIDsByEntityName(nttName);
	}

	@GetMapping("/getAllChainsUnderChain")
	public List<DIM> getAllChainsUnderChain() {
		return mpsService.getAllChainsUnderChain();
	}

	@GetMapping("/getAllEntitiesUnderEntity")
	public List<DIM> getAllEntitiesUnderEntity() {
		return mpsService.getAllEntitiesUnderEntity();
	}

}
