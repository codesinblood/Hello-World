package com.elavon.app.api.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.neo4j.repository.query.Query;
import org.springframework.stereotype.Repository;

import com.elavon.app.api.entity.Root;
import com.elavon.app.api.entity.CAN;
import com.elavon.app.api.entity.Client;
import com.elavon.app.api.entity.NTT;


@Repository
public interface NTTRepo extends Neo4jRepository<NTT, Long> {
	Optional<NTT> findByNttCode(String nttCode);
	Optional<NTT> findByNttName(String nttName);
	
}
